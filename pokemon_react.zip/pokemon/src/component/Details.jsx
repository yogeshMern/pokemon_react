import { useLocation } from "react-router-dom";
import '../styles/Details.css';
import { Link } from "react-router-dom";

const Details = () => {
    const { pokimon } = useLocation().state;

    return (
        <div 
            style={{
                backgroundImage: `url(${pokimon?.sprites?.other?.dream_world?.front_default})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                backgroundAttachment: "fixed",
                height: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
                color: "white",
                textAlign: "center",
                padding: "20px"
            }}
        >
            {/* Pokémon Name */}
            <h1 style={{ fontSize: "3rem", fontWeight: "bold", textShadow: "2px 2px 10px rgba(0, 0, 0, 0.7)" }}>
                {pokimon?.name.toUpperCase()}
            </h1>

            {/* Pokémon Details */}
            <div 
                style={{
                    background: "rgba(0, 0, 0, 0.6)",
                    padding: "20px",
                    borderRadius: "15px",
                    maxWidth: "600px",
                    textAlign: "left",
                }}
            >
                {/* Types */}
                <h2 style={{ color: "#f8d030" }}>Abilities</h2>
                <ul style={{ listStyleType: "none", padding: 0 }}>
                    {pokimon?.types.map((item, index) => (
                        <li key={index} style={{ fontSize: "1.2rem" }}>
                            {item.type.name.toUpperCase()}
                        </li>
                    ))}
                </ul>

                {/* Abilities */}
                <h2 style={{ color: "#f8d030" }}>Abilities</h2>
                <ul style={{ listStyleType: "none", padding: 0 }}>
                    {pokimon?.abilities.map((item, index) => (
                        <li key={index} style={{ fontSize: "1.2rem" }}>
                            {item.ability.name.toUpperCase()}
                        </li>
                    ))}
                </ul>

                {/* Stats */}
                <h2 style={{ color: "#78c850" }}>Stats</h2>
                <ul style={{ listStyleType: "none", padding: 0 }}>
                    {pokimon?.stats.map((stat, index) => (
                        <li key={index} style={{ fontSize: "1.2rem" }}>
                            {stat.stat.name.toUpperCase()}: <strong>{stat.base_stat}</strong>
                        </li>
                    ))}
                </ul>

                {/* Moves (First 5 for better UI) */}
                <h2 style={{ color: "#6890f0" }}>Moves</h2>
                <ul style={{ listStyleType: "none", padding: 0 }}>
                    {pokimon?.moves.slice(0, 5).map((move, index) => (
                        <li key={index} style={{ fontSize: "1.2rem" }}>
                            {move.move.name.toUpperCase()}
                        </li>
                    ))}
                </ul>
            </div>

            {/* Go Back Button */}
            <div style={{ marginTop: "20px" }}>
                <button 
                    style={{
                        background: "#ff6f61",
                        color: "white",
                        border: "none",
                        padding: "10px 20px",
                        borderRadius: "10px",
                        cursor: "pointer",
                        fontSize: "1.2rem",
                        textDecoration: "none",
                    }}
                >
                    <Link to="/" style={{ textDecoration: "none", color: "white", cursor: "pointer" }}>
                        Go Back
                    </Link>
                </button>
            </div>
        </div>
    );
}

export default Details;
