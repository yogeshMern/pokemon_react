import React from "react";
import { useNavigate } from "react-router-dom";
import "../styles/Pokimon.css";

const Card = ({ ele }) => {
  const navigate = useNavigate();

  const sendDetails = () => {
    navigate(`./details/${ele?.id}`, { state: { pokimon: ele } });
  };

  return (
    <div
      onClick={sendDetails}
      className="card"
      style={{
        backgroundImage: `url(${ele?.sprites?.other?.dream_world?.front_default})`,
        width: "250px",
        backgroundSize: "cover", 
        backgroundPosition: "center",
        cursor:"pointer"
      }}
    >
      <h2 className="title">{ele.name}</h2>
    </div>
  );
};

export default Card;
