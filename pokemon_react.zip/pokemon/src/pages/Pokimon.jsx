import React, { useEffect, useState } from "react";
import "../styles/Pokimon.css";
import Card from "../component/Card";

const Pokimon = () => {
  const [pokimonn, setPokimonn] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setError] = useState(null);

  const [search, setSearch] = useState("");

  const fetchPokimon = async () => {
    try {
      const response = await fetch("https://pokeapi.co/api/v2/pokemon?limit=100");
      const data = await response.json();

      const pokimonDetails = await Promise.all(
        data.results.map(async (currpokimon) => {
          const res = await fetch(currpokimon.url);
          return res.json();
        })
      );

      setPokimonn(pokimonDetails);
      setLoading(false);
    } catch (error) {
      console.log("<==:fetchpokimon error:==>", error);
      setLoading(false);
      setError(error);
    }
  };

  useEffect(() => {
    fetchPokimon();
  }, []);

  // search functionality...

  const searchPokimon = pokimonn.filter((currentPokemon) => 
    currentPokemon.name.toLowerCase().includes(search.toLowerCase())
  );

  if(loading) {
    return (
        <div>
            <h1>Loading...</h1>
        </div>
    )
  }

  if(err) {
    return (
        <div>
            <h1>{err.message}</h1>
        </div>
    )
  } 

  return (
    <>
      <img style={{ width: "100px" }} src="./src/logo.png" alt="Logo" />
      <input className="input" type="text" placeholder="Balma, Bulbasaur, Pikachu, etc." value={search} onChange={(e) => setSearch(e.target.value)} />

      <div className="pokemon-container">
        {searchPokimon.map((ele) => (
            // {pokimonn.map((ele) => (
          <Card key={ele.id} ele={ele}/>
        ))}
      </div>
    </>
  );
};

export default Pokimon;
